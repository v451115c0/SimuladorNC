<?php $__env->startSection('resultados'); ?>
    Cadena 1(Paises): &nbsp; <?php echo e($cadena1); ?><br>
    Cadena 2(PI WATER): &nbsp; <?php echo e($cadena2); ?><br>
    Cadena 3(WATERFALL): &nbsp; <?php echo e($cadena3); ?><br>
    Cadena 4(AQUA POUR): &nbsp; <?php echo e($cadena4); ?><br>
    Cadena 5(OPTIMIZER): &nbsp; <?php echo e($cadena5); ?><br>
    <div class="row">
        <div class="col-lg-12">
            <div class="table-responsive">
                <div>
                    <?php if(count($response)): ?>
                        <table class="table align-items-center table-dark">
                            <thead class="thead-dark">
                                <tr>
                                    <th scope="col">
                                        #
                                    </th>
                                    <th scope="col">
                                        idLevel
                                    </th>
                                    <th scope="col">
                                        Pais
                                    </th>
                                    <th scope="col">
                                        PI WATER
                                    </th>
                                    <th scope="col">
                                        WATERFALL
                                    </th>
                                    <th scope="col">
                                        AQUA POUR
                                    </th>
                                    <th scope="col">
                                        OPTIMIZER
                                    </th>
                                    <th scope="col">
                                        TotalKinya
                                    </th>
                                    <th scope="col">
                                        TotalLvel1
                                    </th>
                                    <th scope="col">
                                        TotalLevel2
                                    </th>
                                    <th scope="col">
                                        CantProd
                                    </th>
                                    <th scope="col">
                                        Total
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="list">
                                <?php
                                    $num = 0;
                                ?>
                                    <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fila): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th>
                                            <?php
                                                $num++;
                                                echo $num;
                                            ?>
                                        </th>
                                        <th>
                                            <?php echo e($fila->idLevel); ?>

                                        </th>
                                        <td>
                                            <?php echo e($fila->Pais); ?>

                                        </td>
                                        <td>
                                            <?php echo e($fila->PW); ?>

                                        </td>
                                        <td>
                                            <?php echo e($fila->Wf); ?>

                                        </td>
                                        <td>
                                            <?php echo e($fila->AP); ?>

                                        </td>
                                        <td>
                                            <?php echo e($fila->Optimizer); ?>

                                        </td>
                                        <td>
                                            <?php echo e($fila->TotalKinya); ?>

                                        </td>
                                        <td>
                                            <?php echo e($fila->Total_Level1); ?>

                                        </td>
                                        <td>
                                            <?php echo e($fila->Total_Level2); ?>

                                        </td>
                                        <td>
                                            <?php echo e($fila->CantProd); ?>

                                        </td>
                                        <td>
                                            <?php echo e($fila->Total); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>    
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\simulador\resources\views/welcome.blade.php ENDPATH**/ ?>